CREATE DATABASE IF NOT EXISTS expense_tracker;

USE expense_tracker;

CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    category VARCHAR(100) NOT NULL,
    expense_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Example Expenses

INSERT INTO expenses
(description, amount, category, expense_date)
VALUES
('Food', 150, 'Food', '2026-10-01'),
('Transport', 80, 'Transport', '2026-10-02'),
('Shopping', 500, 'Shopping', '2026-10-03'),
('Education', 300, 'Education', '2026-10-04'),
('Entertainment', 200, 'Entertainment', '2026-10-05');
